const Page = () => {
  return (
    <div>
      <h1>Welcome to SkillSync</h1>
      <p>This is a training tracker system.</p>
    </div>
  )
}

export default Page
