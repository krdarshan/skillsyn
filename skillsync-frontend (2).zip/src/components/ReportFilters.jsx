"use client"

import { useState } from "react"

const ReportFilters = ({ onExport, userRole, onFilterChange }) => {
  const [filters, setFilters] = useState({
    course: "",
    department: "",
    employee: "",
    startDate: "",
    endDate: "",
    status: "",
  })

  const [isLoading, setIsLoading] = useState(false)

  const courses = [
    "React Fundamentals",
    "JavaScript Advanced",
    "Database Design",
    "Python Basics",
    "Project Management",
    "Data Analytics",
    "Cybersecurity Basics",
  ]

  const departments = ["IT", "Development", "Marketing", "HR", "Sales", "Finance", "Operations"]
  const statuses = ["completed", "in-progress", "enrolled", "not-started"]

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)

    // Call parent component's filter change handler if provided
    if (onFilterChange) {
      onFilterChange(newFilters)
    }
  }

  const handleApplyFilters = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      console.log("Applied filters:", filters)
      alert(`Filters applied successfully!\n${JSON.stringify(filters, null, 2)}`)
      setIsLoading(false)
    }, 1000)
  }

  const handleClearFilters = () => {
    const clearedFilters = {
      course: "",
      department: "",
      employee: "",
      startDate: "",
      endDate: "",
      status: "",
    }
    setFilters(clearedFilters)

    if (onFilterChange) {
      onFilterChange(clearedFilters)
    }

    alert("All filters cleared!")
  }

  const handleExport = async (format) => {
    setIsLoading(true)

    try {
      // Simulate export process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      if (format === "pdf") {
        // Simulate PDF export
        const reportContent = `
SkillSync Training Report - PDF Export
Generated on: ${new Date().toLocaleDateString()}

Filters Applied:
- Course: ${filters.course || "All"}
- Department: ${filters.department || "All"}
- Employee: ${filters.employee || "All"}
- Date Range: ${filters.startDate || "Any"} to ${filters.endDate || "Any"}
- Status: ${filters.status || "All"}

Report Data:
[This would contain the actual report data in a real implementation]
        `

        const blob = new Blob([reportContent], { type: "text/plain" })
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `SkillSync_Report_${new Date().toISOString().split("T")[0]}.txt`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        window.URL.revokeObjectURL(url)
      } else if (format === "excel") {
        // Simulate Excel export
        const csvContent = `Employee Name,Course Title,Department,Status,Completion Date
John Employee,Database Design,IT,Completed,2024-01-15
Jane Smith,React Fundamentals,Development,Completed,2024-01-20
Bob Wilson,JavaScript Advanced,IT,In Progress,
Alice Johnson,Project Management,HR,Completed,2024-01-25`

        const blob = new Blob([csvContent], { type: "text/csv" })
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `SkillSync_Report_${new Date().toISOString().split("T")[0]}.csv`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        window.URL.revokeObjectURL(url)
      }

      alert(`${format.toUpperCase()} report exported successfully!`)

      if (onExport) {
        onExport(format)
      }
    } catch (error) {
      alert(`Error exporting ${format.toUpperCase()} report: ${error.message}`)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-lg border p-6 shadow-sm">
      <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.207A1 1 0 013 6.5V4z"
          />
        </svg>
        Report Filters
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Course</label>
          <select
            value={filters.course}
            onChange={(e) => handleFilterChange("course", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Courses</option>
            {courses.map((course) => (
              <option key={course} value={course}>
                {course}
              </option>
            ))}
          </select>
        </div>

        {userRole === "manager" && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
            <select
              value={filters.department}
              onChange={(e) => handleFilterChange("department", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">All Departments</option>
              {departments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Employee Name</label>
          <input
            type="text"
            value={filters.employee}
            onChange={(e) => handleFilterChange("employee", e.target.value)}
            placeholder="Search employee..."
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
          <select
            value={filters.status}
            onChange={(e) => handleFilterChange("status", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Statuses</option>
            {statuses.map((status) => (
              <option key={status} value={status}>
                {status.charAt(0).toUpperCase() + status.slice(1).replace("-", " ")}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
          <input
            type="date"
            value={filters.startDate}
            onChange={(e) => handleFilterChange("startDate", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
          <input
            type="date"
            value={filters.endDate}
            onChange={(e) => handleFilterChange("endDate", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-4 items-center">
        <button
          onClick={handleApplyFilters}
          disabled={isLoading}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white px-4 py-2 rounded-md font-medium transition-colors flex items-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Applying...
            </>
          ) : (
            "Apply Filters"
          )}
        </button>

        <button
          onClick={handleClearFilters}
          disabled={isLoading}
          className="bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-md font-medium transition-colors"
        >
          Clear Filters
        </button>

        <div className="flex space-x-2 ml-auto">
          <button
            onClick={() => handleExport("pdf")}
            disabled={isLoading}
            className="bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white px-4 py-2 rounded-md font-medium flex items-center space-x-2 transition-colors"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
            <span>Export PDF</span>
          </button>

          <button
            onClick={() => handleExport("excel")}
            disabled={isLoading}
            className="bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white px-4 py-2 rounded-md font-medium flex items-center space-x-2 transition-colors"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      {/* Active Filters Display */}
      {Object.values(filters).some((value) => value !== "") && (
        <div className="mt-4 p-3 bg-blue-50 rounded-md">
          <h4 className="text-sm font-medium text-blue-900 mb-2">Active Filters:</h4>
          <div className="flex flex-wrap gap-2">
            {Object.entries(filters).map(
              ([key, value]) =>
                value && (
                  <span
                    key={key}
                    className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {key}: {value}
                    <button
                      onClick={() => handleFilterChange(key, "")}
                      className="ml-1 text-blue-600 hover:text-blue-800"
                    >
                      ×
                    </button>
                  </span>
                ),
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default ReportFilters
