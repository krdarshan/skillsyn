"use client"

const CertificateCard = ({ certificate }) => {
  const handleDownload = () => {
    // Create a more realistic download simulation
    const downloadData = {
      certificateId: certificate.certificateId,
      courseTitle: certificate.courseTitle,
      employeeName: certificate.employeeName,
      completedDate: certificate.completedDate,
      trainer: certificate.trainer,
      downloadDate: new Date().toISOString().split("T")[0],
    }

    // Simulate PDF generation
    console.log("Generating PDF certificate with data:", downloadData)

    // Create a blob URL for download simulation
    const pdfContent = `
Certificate of Completion

This is to certify that
${certificate.employeeName}

has successfully completed the course
${certificate.courseTitle}

Completed on: ${certificate.completedDate}
Certificate ID: ${certificate.certificateId}
Trainer: ${certificate.trainer}

SkillSync Training System
    `

    const blob = new Blob([pdfContent], { type: "text/plain" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${certificate.courseTitle.replace(/\s+/g, "_")}_Certificate.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)

    // Show success message
    alert(`Certificate downloaded successfully!\nFile: ${certificate.courseTitle.replace(/\s+/g, "_")}_Certificate.txt`)
  }

  const handleView = () => {
    // Open certificate in new window for viewing
    const certificateHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Certificate - ${certificate.courseTitle}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 40px; text-align: center; }
          .certificate { border: 3px solid #4F46E5; padding: 40px; margin: 20px; }
          .title { font-size: 28px; color: #4F46E5; margin-bottom: 20px; }
          .subtitle { font-size: 18px; margin-bottom: 30px; }
          .name { font-size: 24px; font-weight: bold; color: #1F2937; margin: 20px 0; }
          .course { font-size: 20px; color: #4F46E5; margin: 20px 0; }
          .details { margin-top: 30px; font-size: 14px; color: #6B7280; }
        </style>
      </head>
      <body>
        <div class="certificate">
          <div class="title">🏆 CERTIFICATE OF COMPLETION</div>
          <div class="subtitle">This is to certify that</div>
          <div class="name">${certificate.employeeName}</div>
          <div class="subtitle">has successfully completed the course</div>
          <div class="course">${certificate.courseTitle}</div>
          <div class="details">
            <p>Completed on: ${certificate.completedDate}</p>
            <p>Certificate ID: ${certificate.certificateId}</p>
            <p>Trainer: ${certificate.trainer}</p>
            <p>Issued by: SkillSync Training System</p>
          </div>
        </div>
      </body>
      </html>
    `

    const newWindow = window.open("", "_blank")
    newWindow.document.write(certificateHTML)
    newWindow.document.close()
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">{certificate.courseTitle}</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <p className="flex items-center">
              <span className="font-medium mr-2">Certificate ID:</span>
              <span className="font-mono bg-gray-100 px-2 py-1 rounded text-xs">{certificate.certificateId}</span>
            </p>
            <p>
              <span className="font-medium">Completed:</span> {certificate.completedDate}
            </p>
            <p>
              <span className="font-medium">Trainer:</span> {certificate.trainer}
            </p>
          </div>
        </div>
        <div className="text-purple-600 ml-4">
          <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
              clipRule="evenodd"
            />
          </svg>
        </div>
      </div>

      <div className="flex space-x-2">
        <button
          onClick={handleView}
          className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-md font-medium flex items-center justify-center space-x-2 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
            />
          </svg>
          <span>View</span>
        </button>

        <button
          onClick={handleDownload}
          className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-md font-medium flex items-center justify-center space-x-2 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
          <span>Download</span>
        </button>
      </div>
    </div>
  )
}

export default CertificateCard
