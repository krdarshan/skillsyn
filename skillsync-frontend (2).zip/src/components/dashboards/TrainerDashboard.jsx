"use client"

import { useState, useEffect } from "react"
import { useAuth } from "../../contexts/AuthContext"
import CourseCard from "../CourseCard"
import ReportFilters from "../ReportFilters"

const TrainerDashboard = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("courses")
  const [courses, setCourses] = useState([])
  const [reports, setReports] = useState([])
  const [filteredReports, setFilteredReports] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Load trainer's data
    const loadData = () => {
      // Mock data for trainer's assigned courses
      const trainerCourses = [
        {
          id: 1,
          title: "React Fundamentals",
          description: "Learn the basics of React development including components, props, and state management",
          trainer: "Sarah Trainer",
          duration: "4 weeks",
          enrolledCount: 15,
          completedCount: 8,
          status: "active",
          category: "Frontend Development",
          startDate: "2024-01-01",
        },
        {
          id: 2,
          title: "JavaScript Advanced",
          description: "Advanced JavaScript concepts including closures, promises, and async/await",
          trainer: "Sarah Trainer",
          duration: "6 weeks",
          enrolledCount: 12,
          completedCount: 5,
          status: "active",
          category: "Programming",
          startDate: "2024-01-15",
        },
        {
          id: 3,
          title: "Database Design",
          description: "Learn database design principles, normalization, and SQL optimization",
          trainer: "Sarah Trainer",
          duration: "3 weeks",
          enrolledCount: 20,
          completedCount: 18,
          status: "completed",
          category: "Backend Development",
          startDate: "2023-12-01",
        },
      ]

      const trainerReports = [
        {
          id: 1,
          employeeName: "John Employee",
          courseTitle: "Database Design",
          department: "IT",
          completedDate: "2024-01-15",
          status: "completed",
          progress: 100,
          certificateId: "CERT-2024-001",
        },
        {
          id: 2,
          employeeName: "Jane Smith",
          courseTitle: "React Fundamentals",
          department: "Development",
          completedDate: "2024-01-20",
          status: "completed",
          progress: 100,
          certificateId: "CERT-2024-002",
        },
        {
          id: 3,
          employeeName: "Bob Wilson",
          courseTitle: "JavaScript Advanced",
          department: "IT",
          completedDate: null,
          status: "in-progress",
          progress: 65,
          certificateId: null,
        },
        {
          id: 4,
          employeeName: "Alice Johnson",
          courseTitle: "React Fundamentals",
          department: "Marketing",
          completedDate: "2024-01-25",
          status: "completed",
          progress: 100,
          certificateId: "CERT-2024-003",
        },
      ]

      setCourses(trainerCourses)
      setReports(trainerReports)
      setFilteredReports(trainerReports)
      setLoading(false)
    }

    loadData()
  }, [])

  const handleFilterChange = (filters) => {
    let filtered = [...reports]

    if (filters.course) {
      filtered = filtered.filter((report) => report.courseTitle === filters.course)
    }

    if (filters.employee) {
      filtered = filtered.filter((report) => report.employeeName.toLowerCase().includes(filters.employee.toLowerCase()))
    }

    if (filters.status) {
      filtered = filtered.filter((report) => report.status === filters.status)
    }

    if (filters.startDate) {
      filtered = filtered.filter((report) => report.completedDate && report.completedDate >= filters.startDate)
    }

    if (filters.endDate) {
      filtered = filtered.filter((report) => report.completedDate && report.completedDate <= filters.endDate)
    }

    setFilteredReports(filtered)
  }

  const stats = [
    {
      label: "Assigned Courses",
      value: courses.length,
      color: "blue",
      icon: "📚",
    },
    {
      label: "Total Enrollments",
      value: courses.reduce((sum, c) => sum + c.enrolledCount, 0),
      color: "green",
      icon: "👥",
    },
    {
      label: "Completed Training",
      value: courses.reduce((sum, c) => sum + c.completedCount, 0),
      color: "purple",
      icon: "✅",
    },
    {
      label: "Active Courses",
      value: courses.filter((c) => c.status === "active").length,
      color: "yellow",
      icon: "🔄",
    },
  ]

  const handleExportReport = (format) => {
    console.log(`Exporting trainer report as ${format} with ${filteredReports.length} records`)
    // Export functionality is handled in ReportFilters component
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Trainer Dashboard 👨‍🏫</h1>
        <p className="text-gray-600">Manage your assigned courses and monitor student progress.</p>
        <div className="mt-4 text-sm text-gray-500">
          Welcome back, {user.name} | Department: {user.department}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className={`p-3 rounded-full bg-${stat.color}-100 mr-4`}>
                <span className="text-2xl">{stat.icon}</span>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab("courses")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "courses"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              My Courses ({courses.length})
            </button>
            <button
              onClick={() => setActiveTab("reports")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "reports"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Training Reports ({filteredReports.length})
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "courses" && (
            <div className="space-y-6">
              {courses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {courses.map((course) => (
                    <CourseCard key={course.id} course={course} userRole="trainer" />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-lg mb-2">No courses assigned</div>
                  <p className="text-gray-500">Contact your manager to get course assignments</p>
                </div>
              )}
            </div>
          )}

          {activeTab === "reports" && (
            <div className="space-y-6">
              <ReportFilters onExport={handleExportReport} userRole="trainer" onFilterChange={handleFilterChange} />

              <div className="bg-white rounded-lg border">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">
                    Training Completion Reports ({filteredReports.length} records)
                  </h3>
                </div>
                <div className="overflow-x-auto">
                  {filteredReports.length > 0 ? (
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Employee
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Course
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Department
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progress
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Completed Date
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredReports.map((report) => (
                          <tr key={report.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {report.employeeName}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.courseTitle}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.department}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <div className="flex items-center">
                                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                  <div
                                    className={`h-2 rounded-full ${
                                      report.progress === 100 ? "bg-green-600" : "bg-blue-600"
                                    }`}
                                    style={{ width: `${report.progress}%` }}
                                  ></div>
                                </div>
                                <span className="text-xs">{report.progress}%</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span
                                className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  report.status === "completed"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-yellow-100 text-yellow-800"
                                }`}
                              >
                                {report.status.replace("-", " ")}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {report.completedDate || "In Progress"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="text-center py-12">
                      <div className="text-gray-400 text-lg mb-2">No reports found</div>
                      <p className="text-gray-500">Try adjusting your filters</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default TrainerDashboard
