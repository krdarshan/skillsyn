"use client"

import { useState, useEffect } from "react"
import { useAuth } from "../../contexts/AuthContext"
import CourseCard from "../CourseCard"
import ReportFilters from "../ReportFilters"
import CourseForm from "../CourseForm"

const ManagerDashboard = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")
  const [courses, setCourses] = useState([])
  const [reports, setReports] = useState([])
  const [filteredReports, setFilteredReports] = useState([])
  const [showCourseForm, setShowCourseForm] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = () => {
      // Load courses from localStorage or set defaults
      const storedCourses = localStorage.getItem("skillsync_all_courses")

      let allCourses
      if (storedCourses) {
        allCourses = JSON.parse(storedCourses)
      } else {
        allCourses = [
          {
            id: 1,
            title: "React Fundamentals",
            description: "Learn the basics of React development including components, props, and state management",
            trainer: "Sarah Trainer",
            duration: "4 weeks",
            enrolledCount: 15,
            completedCount: 8,
            status: "active",
            category: "Frontend Development",
            createdDate: "2024-01-01",
          },
          {
            id: 2,
            title: "JavaScript Advanced",
            description: "Advanced JavaScript concepts including closures, promises, and async/await",
            trainer: "Sarah Trainer",
            duration: "6 weeks",
            enrolledCount: 12,
            completedCount: 5,
            status: "active",
            category: "Programming",
            createdDate: "2024-01-15",
          },
          {
            id: 3,
            title: "Database Design",
            description: "Learn database design principles, normalization, and SQL optimization",
            trainer: "Sarah Trainer",
            duration: "3 weeks",
            enrolledCount: 20,
            completedCount: 18,
            status: "completed",
            category: "Backend Development",
            createdDate: "2023-12-01",
          },
          {
            id: 4,
            title: "Project Management Basics",
            description: "Introduction to project management methodologies and tools",
            trainer: "Mike Teacher",
            duration: "2 weeks",
            enrolledCount: 8,
            completedCount: 6,
            status: "active",
            category: "Management",
            createdDate: "2024-01-10",
          },
        ]
        localStorage.setItem("skillsync_all_courses", JSON.stringify(allCourses))
      }

      const allReports = [
        {
          id: 1,
          employeeName: "John Employee",
          courseTitle: "Database Design",
          department: "IT",
          completedDate: "2024-01-15",
          status: "completed",
          progress: 100,
          trainer: "Sarah Trainer",
        },
        {
          id: 2,
          employeeName: "Jane Smith",
          courseTitle: "React Fundamentals",
          department: "Development",
          completedDate: "2024-01-20",
          status: "completed",
          progress: 100,
          trainer: "Sarah Trainer",
        },
        {
          id: 3,
          employeeName: "Bob Wilson",
          courseTitle: "JavaScript Advanced",
          department: "IT",
          completedDate: "2024-01-25",
          status: "completed",
          progress: 100,
          trainer: "Sarah Trainer",
        },
        {
          id: 4,
          employeeName: "Alice Johnson",
          courseTitle: "Project Management Basics",
          department: "HR",
          completedDate: "2024-01-22",
          status: "completed",
          progress: 100,
          trainer: "Mike Teacher",
        },
        {
          id: 5,
          employeeName: "Charlie Brown",
          courseTitle: "React Fundamentals",
          department: "Marketing",
          completedDate: null,
          status: "in-progress",
          progress: 75,
          trainer: "Sarah Trainer",
        },
      ]

      setCourses(allCourses)
      setReports(allReports)
      setFilteredReports(allReports)
      setLoading(false)
    }

    loadData()
  }, [])

  const handleCreateCourse = (courseData) => {
    const newCourse = {
      ...courseData,
      id: Date.now(),
      enrolledCount: 0,
      completedCount: 0,
      status: "active",
    }

    const updatedCourses = [...courses, newCourse]
    setCourses(updatedCourses)
    localStorage.setItem("skillsync_all_courses", JSON.stringify(updatedCourses))
    setShowCourseForm(false)
  }

  const handleFilterChange = (filters) => {
    let filtered = [...reports]

    if (filters.course) {
      filtered = filtered.filter((report) => report.courseTitle === filters.course)
    }

    if (filters.department) {
      filtered = filtered.filter((report) => report.department === filters.department)
    }

    if (filters.employee) {
      filtered = filtered.filter((report) => report.employeeName.toLowerCase().includes(filters.employee.toLowerCase()))
    }

    if (filters.status) {
      filtered = filtered.filter((report) => report.status === filters.status)
    }

    if (filters.startDate) {
      filtered = filtered.filter((report) => report.completedDate && report.completedDate >= filters.startDate)
    }

    if (filters.endDate) {
      filtered = filtered.filter((report) => report.completedDate && report.completedDate <= filters.endDate)
    }

    setFilteredReports(filtered)
  }

  const handleExportReport = (format) => {
    console.log(`Exporting comprehensive report as ${format} with ${filteredReports.length} records`)
    // Export functionality is handled in ReportFilters component
  }

  const stats = [
    {
      label: "Total Courses",
      value: courses.length,
      color: "blue",
      icon: "📚",
    },
    {
      label: "Total Enrollments",
      value: courses.reduce((sum, c) => sum + c.enrolledCount, 0),
      color: "green",
      icon: "👥",
    },
    {
      label: "Certificates Issued",
      value: courses.reduce((sum, c) => sum + c.completedCount, 0),
      color: "purple",
      icon: "🏆",
    },
    {
      label: "Active Courses",
      value: courses.filter((c) => c.status === "active").length,
      color: "yellow",
      icon: "🔄",
    },
  ]

  const departmentStats = [
    { department: "IT", completed: 15, total: 25, percentage: 60 },
    { department: "Development", completed: 12, total: 18, percentage: 67 },
    { department: "Marketing", completed: 8, total: 12, percentage: 67 },
    { department: "HR", completed: 6, total: 8, percentage: 75 },
    { department: "Sales", completed: 4, total: 10, percentage: 40 },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Manager Dashboard 👨‍💼</h1>
            <p className="text-gray-600">Manage all training activities and view comprehensive reports.</p>
            <div className="mt-4 text-sm text-gray-500">
              Welcome back, {user.name} | Department: {user.department}
            </div>
          </div>
          <button
            onClick={() => setShowCourseForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors flex items-center"
          >
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Create Course
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className={`p-3 rounded-full bg-${stat.color}-100 mr-4`}>
                <span className="text-2xl">{stat.icon}</span>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab("overview")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "overview"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab("courses")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "courses"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              All Courses ({courses.length})
            </button>
            <button
              onClick={() => setActiveTab("reports")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "reports"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Comprehensive Reports ({filteredReports.length})
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Department-wise Completion</h3>
                  <div className="space-y-4">
                    {departmentStats.map((dept, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700 min-w-0 flex-1">{dept.department}</span>
                        <div className="flex items-center space-x-3 ml-4">
                          <div className="w-32 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${dept.percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600 min-w-0">
                            {dept.completed}/{dept.total}
                          </span>
                          <span className="text-xs text-gray-500 min-w-0">({dept.percentage}%)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {reports.slice(0, 8).map((report, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            report.status === "completed" ? "bg-green-500" : "bg-yellow-500"
                          }`}
                        ></div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-gray-900">
                            <span className="font-medium">{report.employeeName}</span>
                            {report.status === "completed" ? " completed " : " is progressing in "}
                            <span className="font-medium">{report.courseTitle}</span>
                          </p>
                          <p className="text-xs text-gray-500">
                            {report.department} • {report.completedDate || `${report.progress}% complete`}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "courses" && (
            <div className="space-y-6">
              {courses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {courses.map((course) => (
                    <CourseCard key={course.id} course={course} userRole="manager" />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-lg mb-2">No courses available</div>
                  <p className="text-gray-500">Create your first course to get started</p>
                </div>
              )}
            </div>
          )}

          {activeTab === "reports" && (
            <div className="space-y-6">
              <ReportFilters onExport={handleExportReport} userRole="manager" onFilterChange={handleFilterChange} />

              <div className="bg-white rounded-lg border">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">
                    All Training Reports ({filteredReports.length} records)
                  </h3>
                </div>
                <div className="overflow-x-auto">
                  {filteredReports.length > 0 ? (
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Employee
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Course
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Department
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Trainer
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progress
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Completed Date
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredReports.map((report) => (
                          <tr key={report.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {report.employeeName}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.courseTitle}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.department}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.trainer}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <div className="flex items-center">
                                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                  <div
                                    className={`h-2 rounded-full ${
                                      report.progress === 100 ? "bg-green-600" : "bg-blue-600"
                                    }`}
                                    style={{ width: `${report.progress}%` }}
                                  ></div>
                                </div>
                                <span className="text-xs">{report.progress}%</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span
                                className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  report.status === "completed"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-yellow-100 text-yellow-800"
                                }`}
                              >
                                {report.status.replace("-", " ")}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {report.completedDate || "In Progress"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="text-center py-12">
                      <div className="text-gray-400 text-lg mb-2">No reports found</div>
                      <p className="text-gray-500">Try adjusting your filters</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Course Form Modal */}
      {showCourseForm && <CourseForm onSubmit={handleCreateCourse} onCancel={() => setShowCourseForm(false)} />}
    </div>
  )
}

export default ManagerDashboard
