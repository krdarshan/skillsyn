"use client"

import { useState, useEffect } from "react"
import { useAuth } from "../../contexts/AuthContext"
import CourseCard from "../CourseCard"
import CertificateCard from "../CertificateCard"

const EmployeeDashboard = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("courses")
  const [courses, setCourses] = useState([])
  const [certificates, setCertificates] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Load data from localStorage or set default data
    const loadData = () => {
      const storedCourses = localStorage.getItem(`skillsync_courses_${user.id}`)
      const storedCertificates = localStorage.getItem(`skillsync_certificates_${user.id}`)

      if (storedCourses) {
        setCourses(JSON.parse(storedCourses))
      } else {
        // Default courses for employee
        const defaultCourses = [
          {
            id: 1,
            title: "React Fundamentals",
            description: "Learn the basics of React development including components, props, and state management",
            trainer: "Sarah Trainer",
            duration: "4 weeks",
            status: "available",
            enrolled: false,
            progress: 0,
            category: "Frontend Development",
          },
          {
            id: 2,
            title: "JavaScript Advanced",
            description: "Advanced JavaScript concepts including closures, promises, and async/await",
            trainer: "Sarah Trainer",
            duration: "6 weeks",
            status: "in-progress",
            enrolled: true,
            progress: 65,
            category: "Programming",
          },
          {
            id: 3,
            title: "Database Design",
            description: "Learn database design principles, normalization, and SQL optimization",
            trainer: "Sarah Trainer",
            duration: "3 weeks",
            status: "completed",
            enrolled: true,
            progress: 100,
            completedDate: "2024-01-15",
            category: "Backend Development",
          },
          {
            id: 4,
            title: "Project Management Basics",
            description: "Introduction to project management methodologies and tools",
            trainer: "Mike Teacher",
            duration: "2 weeks",
            status: "available",
            enrolled: false,
            progress: 0,
            category: "Management",
          },
        ]
        setCourses(defaultCourses)
        localStorage.setItem(`skillsync_courses_${user.id}`, JSON.stringify(defaultCourses))
      }

      if (storedCertificates) {
        setCertificates(JSON.parse(storedCertificates))
      } else {
        // Default certificates
        const defaultCertificates = [
          {
            id: 1,
            courseTitle: "Database Design",
            completedDate: "2024-01-15",
            certificateId: "CERT-2024-001",
            downloadUrl: "#",
            employeeName: user.name,
            trainer: "Sarah Trainer",
          },
        ]
        setCertificates(defaultCertificates)
        localStorage.setItem(`skillsync_certificates_${user.id}`, JSON.stringify(defaultCertificates))
      }

      setLoading(false)
    }

    if (user) {
      loadData()
    }
  }, [user])

  const handleEnroll = (courseId) => {
    const updatedCourses = courses.map((course) =>
      course.id === courseId ? { ...course, enrolled: true, status: "in-progress", progress: 0 } : course,
    )
    setCourses(updatedCourses)
    localStorage.setItem(`skillsync_courses_${user.id}`, JSON.stringify(updatedCourses))

    // Show success message
    alert("Successfully enrolled in the course!")
  }

  const handleContinueLearning = (courseId) => {
    // Simulate progress update
    const updatedCourses = courses.map((course) =>
      course.id === courseId ? { ...course, progress: Math.min(course.progress + 10, 100) } : course,
    )
    setCourses(updatedCourses)
    localStorage.setItem(`skillsync_courses_${user.id}`, JSON.stringify(updatedCourses))

    // Check if course is completed
    const completedCourse = updatedCourses.find((c) => c.id === courseId && c.progress === 100)
    if (completedCourse && completedCourse.status !== "completed") {
      // Mark as completed and generate certificate
      const finalCourses = updatedCourses.map((c) =>
        c.id === courseId ? { ...c, status: "completed", completedDate: new Date().toISOString().split("T")[0] } : c,
      )
      setCourses(finalCourses)
      localStorage.setItem(`skillsync_courses_${user.id}`, JSON.stringify(finalCourses))

      // Generate certificate
      const newCertificate = {
        id: certificates.length + 1,
        courseTitle: completedCourse.title,
        completedDate: new Date().toISOString().split("T")[0],
        certificateId: `CERT-2024-${String(certificates.length + 1).padStart(3, "0")}`,
        downloadUrl: "#",
        employeeName: user.name,
        trainer: completedCourse.trainer,
      }

      const updatedCertificates = [...certificates, newCertificate]
      setCertificates(updatedCertificates)
      localStorage.setItem(`skillsync_certificates_${user.id}`, JSON.stringify(updatedCertificates))

      alert("Congratulations! Course completed. Certificate generated!")
    }
  }

  const stats = [
    {
      label: "Enrolled Courses",
      value: courses.filter((c) => c.enrolled).length,
      color: "blue",
      icon: "📚",
    },
    {
      label: "Completed Courses",
      value: courses.filter((c) => c.status === "completed").length,
      color: "green",
      icon: "✅",
    },
    {
      label: "Certificates Earned",
      value: certificates.length,
      color: "purple",
      icon: "🏆",
    },
    {
      label: "In Progress",
      value: courses.filter((c) => c.status === "in-progress").length,
      color: "yellow",
      icon: "⏳",
    },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome back, {user.name}! 👋</h1>
        <p className="text-gray-600">Track your learning progress and manage your training.</p>
        <div className="mt-4 text-sm text-gray-500">
          Department: {user.department} | Member since: {user.joinDate}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className={`p-3 rounded-full bg-${stat.color}-100 mr-4`}>
                <span className="text-2xl">{stat.icon}</span>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab("courses")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "courses"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Available Courses ({courses.length})
            </button>
            <button
              onClick={() => setActiveTab("certificates")}
              className={`py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "certificates"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              My Certificates ({certificates.length})
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "courses" && (
            <div className="space-y-6">
              {courses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {courses.map((course) => (
                    <CourseCard
                      key={course.id}
                      course={course}
                      onEnroll={handleEnroll}
                      onContinue={handleContinueLearning}
                      userRole="employee"
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-lg mb-2">No courses available</div>
                  <p className="text-gray-500">Check back later for new training opportunities</p>
                </div>
              )}
            </div>
          )}

          {activeTab === "certificates" && (
            <div className="space-y-6">
              {certificates.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {certificates.map((certificate) => (
                    <CertificateCard key={certificate.id} certificate={certificate} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-lg mb-2">No certificates yet 📜</div>
                  <p className="text-gray-500">Complete courses to earn certificates</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default EmployeeDashboard
