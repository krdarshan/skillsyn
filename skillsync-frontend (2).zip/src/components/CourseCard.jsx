"use client"

const CourseCard = ({ course, onEnroll, onContinue, userRole }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case "available":
        return "bg-blue-100 text-blue-800"
      case "in-progress":
        return "bg-yellow-100 text-yellow-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "active":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleDownloadCertificate = () => {
    // Mock certificate download
    const certificateData = {
      courseName: course.title,
      studentName: "Current User", // This would come from auth context
      completionDate: course.completedDate,
      certificateId: `CERT-${course.id}-${Date.now()}`,
    }

    alert(`Certificate downloaded for ${course.title}!\nCertificate ID: ${certificateData.certificateId}`)
  }

  const renderEmployeeActions = () => {
    if (course.status === "available" && !course.enrolled) {
      return (
        <button
          onClick={() => onEnroll(course.id)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
        >
          Enroll Now
        </button>
      )
    }

    if (course.status === "in-progress" && course.enrolled) {
      return (
        <div className="space-y-3">
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-blue-600 h-3 rounded-full transition-all duration-300"
              style={{ width: `${course.progress}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-600 text-center font-medium">{course.progress}% Complete</p>
          <button
            onClick={() => onContinue(course.id)}
            className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
          >
            Continue Learning
          </button>
        </div>
      )
    }

    if (course.status === "completed") {
      return (
        <div className="space-y-3">
          <div className="w-full bg-green-200 rounded-full h-3">
            <div className="bg-green-600 h-3 rounded-full w-full"></div>
          </div>
          <p className="text-sm text-green-600 text-center font-medium flex items-center justify-center">
            <span className="mr-1">✅</span> Completed on {course.completedDate}
          </p>
          <button
            onClick={handleDownloadCertificate}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-md font-medium transition-colors flex items-center justify-center"
          >
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            Download Certificate
          </button>
        </div>
      )
    }

    return null
  }

  const renderTrainerActions = () => {
    const completionRate =
      course.enrolledCount > 0 ? Math.round((course.completedCount / course.enrolledCount) * 100) : 0

    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="text-center p-2 bg-blue-50 rounded">
            <div className="font-bold text-blue-600">{course.enrolledCount}</div>
            <div className="text-gray-600">Enrolled</div>
          </div>
          <div className="text-center p-2 bg-green-50 rounded">
            <div className="font-bold text-green-600">{course.completedCount}</div>
            <div className="text-gray-600">Completed</div>
          </div>
        </div>
        <div className="text-center text-sm text-gray-600">Completion Rate: {completionRate}%</div>
        <button
          onClick={() => alert(`Managing course: ${course.title}`)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
        >
          Manage Course
        </button>
      </div>
    )
  }

  const renderManagerActions = () => {
    const completionRate =
      course.enrolledCount > 0 ? Math.round((course.completedCount / course.enrolledCount) * 100) : 0

    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="text-center p-2 bg-blue-50 rounded">
            <div className="font-bold text-blue-600">{course.enrolledCount}</div>
            <div className="text-gray-600">Enrolled</div>
          </div>
          <div className="text-center p-2 bg-green-50 rounded">
            <div className="font-bold text-green-600">{course.completedCount}</div>
            <div className="text-gray-600">Completed</div>
          </div>
        </div>
        <div className="text-center text-sm text-gray-600">Completion Rate: {completionRate}%</div>
        <div className="flex space-x-2">
          <button
            onClick={() => alert(`Editing course: ${course.title}`)}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded-md font-medium text-sm transition-colors"
          >
            Edit
          </button>
          <button
            onClick={() => alert(`Assigning course: ${course.title}`)}
            className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-3 rounded-md font-medium text-sm transition-colors"
          >
            Assign
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow border border-gray-100">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">{course.title}</h3>
        <span
          className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ml-2 ${getStatusColor(course.status)}`}
        >
          {course.status.replace("-", " ").toUpperCase()}
        </span>
      </div>

      <p className="text-gray-600 mb-4 text-sm line-clamp-3">{course.description}</p>

      <div className="space-y-2 mb-4 text-sm">
        <div className="flex justify-between text-gray-500">
          <span>Trainer:</span>
          <span className="font-medium text-gray-700">{course.trainer}</span>
        </div>
        <div className="flex justify-between text-gray-500">
          <span>Duration:</span>
          <span className="font-medium text-gray-700">{course.duration}</span>
        </div>
        {course.category && (
          <div className="flex justify-between text-gray-500">
            <span>Category:</span>
            <span className="font-medium text-gray-700">{course.category}</span>
          </div>
        )}
      </div>

      {userRole === "employee" && renderEmployeeActions()}
      {userRole === "trainer" && renderTrainerActions()}
      {userRole === "manager" && renderManagerActions()}
    </div>
  )
}

export default CourseCard
