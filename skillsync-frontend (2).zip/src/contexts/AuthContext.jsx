"use client"

import { createContext, useContext, useState, useEffect } from "react"

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  // Demo users for testing with more complete data
  const demoUsers = {
    "employee@skillsync.com": {
      id: 1,
      email: "employee@skillsync.com",
      name: "John Employee",
      role: "employee",
      department: "IT",
      joinDate: "2023-01-15",
    },
    "trainer@skillsync.com": {
      id: 2,
      email: "trainer@skillsync.com",
      name: "Sarah Trainer",
      role: "trainer",
      department: "Training",
      joinDate: "2022-06-10",
    },
    "manager@skillsync.com": {
      id: 3,
      email: "manager@skillsync.com",
      name: "Mike Manager",
      role: "manager",
      department: "Management",
      joinDate: "2021-03-20",
    },
  }

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem("skillsync_user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        console.error("Error parsing stored user:", error)
        localStorage.removeItem("skillsync_user")
      }
    }
    setLoading(false)
  }, [])

  const login = async (email, password) => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (demoUsers[email] && password === "password") {
      const userData = demoUsers[email]
      setUser(userData)
      localStorage.setItem("skillsync_user", JSON.stringify(userData))
      return { success: true }
    }
    return { success: false, error: "Invalid email or password" }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("skillsync_user")
    // Clear any other stored data
    localStorage.removeItem("skillsync_courses")
    localStorage.removeItem("skillsync_certificates")
  }

  const value = {
    user,
    login,
    logout,
    loading,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
