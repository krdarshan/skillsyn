"use client"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { useAuth } from "./contexts/AuthContext"
import Login from "./components/Login"
import EmployeeDashboard from "./components/dashboards/EmployeeDashboard"
import TrainerDashboard from "./components/dashboards/TrainerDashboard"
import ManagerDashboard from "./components/dashboards/ManagerDashboard"
import Layout from "./components/Layout"

function App() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route path="/login" element={!user ? <Login /> : <Navigate to="/dashboard" />} />
          <Route path="/" element={user ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
          <Route
            path="/dashboard"
            element={
              user ? (
                <Layout>
                  {user.role === "employee" && <EmployeeDashboard />}
                  {user.role === "trainer" && <TrainerDashboard />}
                  {user.role === "manager" && <ManagerDashboard />}
                </Layout>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
        </Routes>
      </div>
    </Router>
  )
}

export default App
